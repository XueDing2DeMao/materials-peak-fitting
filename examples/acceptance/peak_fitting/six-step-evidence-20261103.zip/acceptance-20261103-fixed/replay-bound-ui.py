from pathlib import Path
from playwright.sync_api import sync_playwright
import json,csv,io,datetime
out=Path('output/acceptance-20261103-fixed').resolve();src=out/'sample-package/source/standard.csv'
with sync_playwright() as pw:
 b=pw.chromium.launch(channel='msedge',headless=True);p=b.new_page(viewport={'width':1680,'height':1040},accept_downloads=True);p.set_default_timeout(12000);errors=[];p.on('pageerror',lambda e:errors.append(str(e)))
 p.goto('http://127.0.0.1:5175/');p.get_by_role('combobox',name='分析类型').select_option('xrd');p.locator('input[accept*=xye]').first.set_input_files(str(src));p.get_by_role('button',name='应用到图表',exact=True).click();p.get_by_role('tab',name='峰参数').click();p.get_by_role('button',name='添加峰',exact=True).click();p.get_by_role('button',name='统一调整峰参数（1）',exact=True).click()
 d=p.get_by_role('dialog',name='全部峰参数',exact=True)
 for label,value in [('p1 A 初值','90'),('p1 A 上限','95'),('p1 w 初值','1.8'),('p1 w 下限','1.3'),('p1 xc 初值','5')]:d.get_by_label(label,exact=True).fill(value)
 d.get_by_label('p1 xc 固定',exact=True).check();p.screenshot(path=str(out/'ui/08-bound-inputs.png'));d.get_by_role('button',name='完成',exact=True).click()
 p.get_by_role('tab',name='基线设置').click();p.get_by_role('button',name='预览基线').click();p.get_by_text('已复核当前基线',exact=True).click()
 with p.expect_response(lambda r:r.url.endswith('/api/fit')) as resp:p.get_by_role('button',name='开始拟合',exact=True).click()
 assert resp.value.status==200
 result=resp.value.json();(out/'numerics/bound-ui-response.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
 params=result['parameters']
 assert result['converged'] and abs(params['A']['value']-95)<1e-7 and abs(params['w']['value']-1.3)<1e-7 and params['xc']['value']==5
 for key in ('A','w'):
  assert params[key]['standard_error'] is None and params[key]['confidence_interval'] is None and '贴边' in params[key]['uncertainty_reason'],params[key]
 assert params['xc']['fixed'] and params['xc']['standard_error'] is None and params['xc']['confidence_interval'] is None and '固定' in params['xc']['uncertainty_reason']
 geometry=result['peak_geometry']; height=geometry['peak_height_uncertainty'];assert height['standard_error'] is None and height['confidence_interval'] is None and '贴边' in height['reason']
 p.get_by_role('tab',name='完整参数',exact=True).click();p.locator('[data-test=peak-select-p1]:visible').click();dialog=p.get_by_role('dialog',name='p1 · 峰 1 详细求解结果',exact=True);text=dialog.inner_text()
 assert '贴边' in text and '固定' in text and '95% CI —' in text
 assert '97.1761' not in text and '1.26561' not in text
 (out/'numerics/bound-ui-text.txt').write_text(text,encoding='utf8');p.screenshot(path=str(out/'ui/09-bound-ci-corrected.png'));p.get_by_role('button',name='关闭峰结果详情',exact=True).click()
 p.get_by_role('tab',name='比较与归档').click();p.locator('[data-test=result-export-menu]:visible summary').click()
 with p.expect_download() as dl:p.get_by_role('button',name='参数 CSV',exact=True).click()
 dl.value.save_as(str(out/'downloads/bound-parameters.csv'));assert dl.value.failure() is None
 with (out/'downloads/bound-parameters.csv').open(encoding='utf-8-sig',newline='') as f: rows=list(csv.reader(f))
 header=rows[0];p_rows={r[0]:dict(zip(header,r)) for r in rows[1:] if r and r[0] in ('A','w','xc')}
 assert len(p_rows)==3
 for key in ('A','w','xc'):
  assert p_rows[key]['standard_error']==p_rows[key]['ci95_lower']==p_rows[key]['ci95_upper']==''
  assert ('固定' if key=='xc' else '贴边') in p_rows[key]['uncertainty_reason']
  assert abs(float(p_rows[key]['value'])-params[key]['value'])<1e-10
 assert not errors,errors
 report={'page_errors':errors,'executed_at':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),'browser':'Microsoft Edge '+b.version,'passed':True,'expected':{'A_upper':95,'w_lower':1.3,'xc_fixed':5,'free_parameter_error':None,'free_parameter_interval':None,'free_parameter_reason':'贴边','fixed_parameter_reason':'固定','ui_and_csv_match':True},'actual':{'parameters':params,'height_uncertainty':height,'ui_text':text,'csv_rows':p_rows},'files':['numerics/bound-ui-response.json','numerics/bound-ui-text.txt','ui/08-bound-inputs.png','ui/09-bound-ci-corrected.png','downloads/bound-parameters.csv']}
 (out/'step4-bound-ui-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
 print(json.dumps({'passed':True,'parameters':params,'height_uncertainty':height},ensure_ascii=False));b.close()
