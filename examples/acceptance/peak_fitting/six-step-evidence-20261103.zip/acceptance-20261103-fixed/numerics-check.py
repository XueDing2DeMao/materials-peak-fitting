from pathlib import Path
import json,urllib.request,csv,copy,datetime,hashlib
import numpy as np
from scipy.stats import t
ROOT=Path.cwd(); OUT=ROOT/'output/acceptance-20261103-fixed'; DIR=OUT/'numerics'; DIR.mkdir(exist_ok=True)
PKG=OUT/'sample-package'; ref=json.loads((PKG/'reference.json').read_text(encoding='utf8'))
a=np.loadtxt(PKG/'source/standard.csv',delimiter=',',skiprows=1);x,y=a[:,0],a[:,1]
checks=[]

def save(name,obj):
 (DIR/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf8')

def call(name,endpoint,payload):
 save(name+'-request.json',payload)
 r=urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:5176'+endpoint,json.dumps(payload).encode(),{'Content-Type':'application/json'}),timeout=45)
 result=json.load(r);save(name+'-response.json',result);return result

def record(step,name,expected,actual,ok,evidence):
 checks.append(dict(step=step,name=name,expected=expected,actual=actual,passed=bool(ok),evidence=evidence))
 print(step,name,'PASS' if ok else 'FAIL')

def fit_request(xx,yy,kind='line',anchors=None,model='gaussian',**extra):
 r=dict(x=list(map(float,xx)),y=list(map(float,yy)),model=model,baseline_kind=kind,anchors=anchors or [],range_start=float(xx[0]),range_end=float(xx[-1]),degree=2,smoothing=0,baseline_confirmed=True,anchor_source='manual' if anchors else 'endpoint_default',initial_parameters={'A':80.629409952735,'xc':5,'w':1},parameter_bounds={},fixed_parameters={},staged_fit=True,center_lock_evaluations=20,max_function_evaluations=2000,tolerance=1e-8)
 r.update(extra);return r

def metrics(r):
 g=r['peak_geometry'];return dict(center=g['peak_position'],height=g['peak_height'],fwhm=g['fwhm'],area=g['area_total'])
def verify_truth(step,name,r,truth,evidence):
 values=metrics(r);delta={k:abs(values[k]-truth[k]) for k in values};tol=ref['abs_tolerance'];ok=r['converged'] and all(delta[k]<=tol[k] for k in values)
 record(step,name,{'truth':truth,'absolute_tolerance':tol,'converged':True},{'values':values,'absolute_error':delta,'converged':r['converged'],'rmse':r['statistics']['rmse']},ok,evidence)

truth={'center':5,'height':80,'fwhm':1.2,'area':ref['area']}
plan={'scope':'贴边不确定度修复后的独立HTTP复测；沿用原包和上一轮已确定的容差，不复用旧结果。','created':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),'package_source':str(PKG/'source/standard.csv'),'package_sha256':hashlib.sha256((PKG/'source/standard.csv').read_bytes()).hexdigest(),'baseline_supplement':'从原包standard.csv减去生成时的背景12+0.12*x，保留峰和原来的扰动，再分别加上独立已知基线。','known_baselines':{'none':'0','constant':'7','line':'12+0.12*x','polynomial':'7+0.12*x+0.015*x*x','spline':'7+0.12*x+0.015*x*x+0.001*x**3','bspline':'7+0.12*x+0.015*x*x+0.001*x**3'},'baseline_absolute_tolerance':1e-9,'fit_truth':truth,'fit_absolute_tolerance':ref['abs_tolerance'],'auto_initial_tolerance':{'center':.05,'fwhm':.1,'area_relative':.05},'additional_lorentz':'H/(1+4*((x-5)/1.2)**2)+0.07*sin(1.73*i)+12+0.12*x，H=80，A=H*pi*1.2/2','constraints':'固定xc=5，A上限95、w下限1.3；初值xc=4.6,A=90,w=1.8。比较时使用原包相同x,y,基线和区间。','outlier':'原包standard.csv在x=3.5处加20 counts/s。独立按(abs(residual-mean)/sample_std)>3统计。','uncertainty_reference':'基于拟合后的H,xc,w参数，用独立Gaussian解析Jacobian和RSS/(n-3)求covariance；95%区间乘Student t分位数，比较相对误差小于1e-5。'}
plan['bound_uncertainty_cases'] = {
 'models': ['gaussian', 'lorentz'],
 'upper_area_lower_width': {'A_upper_by_model': {'gaussian': 95, 'lorentz': 140}, 'w_lower': 1.3, 'xc_fixed': 5},
 'lower_area_upper_width': {'A_lower_by_model': {'gaussian': 110, 'lorentz': 160}, 'w_upper': 1.1, 'xc_fixed': 5},
 'center_lower': 5.1,
 'center_upper': 4.9,
 'expectation': '有效边界约束生效且贴边自由参数不输出普通线性SE/CI；covariance为空，明确贴边原因，峰高SE/CI也为空。固定xc为空并说明固定。',
 'bound_value_absolute_tolerance': 1e-6,
 'interior_bounds': {'A': [1, 300], 'w': [.1, 4], 'xc': [4, 6]},
 'interior_expectation': '内部解仍有有限正SE和包含估计值的95%CI，满足原包参数容差。',
 'fixed_only_expectation': '固定xc无SE/CI，其余自由A/w仍有有限正SE和95%CI。',
 'lorentz_se_relative_tolerance': 1e-5,
}
save('test-plan.json',plan)

funcs={'none':lambda z:np.zeros_like(z),'constant':lambda z:np.full_like(z,7),'line':lambda z:12+.12*z,'polynomial':lambda z:7+.12*z+.015*z*z,'spline':lambda z:7+.12*z+.015*z*z+.001*z**3,'bspline':lambda z:7+.12*z+.015*z*z+.001*z**3}
net=y-(12+.12*x);knots=np.linspace(0,10,5)
for kind,bg in funcs.items():
 yy=net+bg(x); anchors=[] if kind=='none' else [dict(x=float(xx),y=float(bv)) for xx,bv in zip(knots,bg(knots))]
 np.savetxt(DIR/(kind+'-standard.csv'),np.column_stack([x,yy]),delimiter=',',header='Angle [deg],Intensity [counts/s]',comments='')
 req=fit_request(x,yy,kind,anchors)
 preview=call('baseline-'+kind,'/api/baseline-preview',req);err=float(np.max(np.abs(np.asarray(preview['baseline'])-bg(x))))
 record(3,'基线 '+kind,{'point_count':201,'max_absolute_error_at_most':1e-9},{'point_count':len(preview['x']),'max_absolute_error':err},len(preview['x'])==201 and err<=1e-9,[f'numerics/baseline-{kind}-request.json',f'numerics/baseline-{kind}-response.json'])
 result=call('fit-baseline-'+kind,'/api/fit',req)
 verify_truth(3,'扣除 '+kind+' 后的峰参数',result,truth,[f'numerics/fit-baseline-{kind}-response.json'])

req=fit_request(x,y)
initial=call('automatic-initial','/api/auto-peak-analysis',req);p=initial['initial_parameters']
record(3,'自动初值',plan['auto_initial_tolerance'],p,abs(p['xc']-5)<=.05 and abs(p['w']-1.2)<=.1 and abs(p['A']/truth['area']-1)<=.05,['numerics/automatic-initial-response.json'])
standard=call('package-gaussian','/api/fit',req);verify_truth(4,'原包 Gaussian 标准谱',standard,truth,['numerics/package-gaussian-response.json'])
manual=copy.deepcopy(req);manual['initial_parameters']={'A':90,'xc':4.7,'w':1.8}
mr=call('manual-initial','/api/fit',manual);verify_truth(4,'修改初值后重新拟合',mr,truth,['numerics/manual-initial-response.json'])
sub=copy.deepcopy(req);sub.update(range_start=2,range_end=8,anchors=[{'x':0.,'y':12.},{'x':10.,'y':13.2}],anchor_source='manual')
sr=call('selected-range','/api/fit',sub)
record(4,'限制拟合区间',{'x_start':2,'x_end':8,'points':121},{'x_start':sr['x'][0],'x_end':sr['x'][-1],'points':len(sr['x'])},sr['x'][0]==2 and sr['x'][-1]==8 and len(sr['x'])==121,['numerics/selected-range-response.json'])
verify_truth(4,'区间内参数',sr,truth,['numerics/selected-range-response.json'])
con=copy.deepcopy(req);con.update(initial_parameters={'A':90,'xc':4.6,'w':1.8},fixed_parameters={'xc':5},parameter_bounds={'A':{'upper':95},'w':{'lower':1.3}})
cr=call('fixed-and-bounds','/api/fit',con);p=cr['parameters'];actual={k:p[k] for k in ['xc','A','w']}
ok=cr['converged'] and p['xc']['value']==5 and p['xc']['fixed'] and p['xc']['standard_error'] is None and abs(p['A']['value']-95)<1e-7 and abs(p['w']['value']-1.3)<1e-7
record(4,'固定与上下限生效',{'xc_fixed':5,'A_upper':95,'w_lower':1.3,'fixed_xc_uncertainty':'留空并注明固定参数'},actual,ok,['numerics/fixed-and-bounds-request.json','numerics/fixed-and-bounds-response.json'])
record(4,'贴边参数不确定度应明确不可用','A和w均位于边界，线性标准误和95%CI留空并明确说明贴边',{name:p[name] for name in ['A','w']},all(p[name]['standard_error'] is None and p[name]['confidence_interval'] is None and bool(p[name]['uncertainty_reason']) for name in ['A','w']),['numerics/fixed-and-bounds-request.json','numerics/fixed-and-bounds-response.json'])
compare=call('compare-gaussian-data','/api/model-comparison',req);rows={r['model']:r for r in compare['rows']}
record(4,'同数据同基线比较 Gaussian/Lorentz',{'gaussian_rmse_lower_than_lorentz':True},{'Gaussian':rows['gaussian'],'Lorentz':rows['lorentz'],'recommended_model':compare['recommended_model']},rows['gaussian']['converged'] and rows['lorentz']['converged'] and rows['gaussian']['rmse']<rows['lorentz']['rmse'],['numerics/compare-gaussian-data-response.json'])
ly=80/(1+4*((x-5)/1.2)**2)+.07*np.sin(1.73*np.arange(len(x)))+12+.12*x
np.savetxt(DIR/'lorentz-standard.csv',np.column_stack([x,ly]),delimiter=',',header='Angle [deg],Intensity [counts/s]',comments='')
lreq=fit_request(x,ly,anchors=[{'x':0.,'y':12.},{'x':10.,'y':13.2}],model='lorentz');lr=call('supplement-lorentz','/api/fit',lreq)
lt={**truth,'area':80*np.pi*1.2/2};verify_truth(4,'补充 Lorentz 已知谱',lr,lt,['numerics/lorentz-standard.csv','numerics/supplement-lorentz-response.json'])
lcompare=call('compare-lorentz-data','/api/model-comparison',lreq);rows={r['model']:r for r in lcompare['rows']}
record(4,'Lorentz 谱同口径模型比较',{'lorentz_rmse_lower_than_gaussian':True},{'Gaussian':rows['gaussian'],'Lorentz':rows['lorentz']},rows['lorentz']['rmse']<rows['gaussian']['rmse'],['numerics/compare-lorentz-data-response.json'])
# 每个模型都检查单侧上下界，边界数值与不确定度分别作为主断言。
def parameter_uncertainty_available(p):
 return (p['standard_error'] is not None and np.isfinite(p['standard_error'])
         and p['standard_error'] > 0 and p['confidence_interval'] is not None
         and all(np.isfinite(p['confidence_interval']))
         and p['confidence_interval'][0] < p['value'] < p['confidence_interval'][1])

for model, source_request, target in [('gaussian', req, truth), ('lorentz', lreq, lt)]:
 cases = [
  ('upper-A-lower-w', {'A': {'upper': 95 if model == 'gaussian' else 140}, 'w': {'lower': 1.3}}, {'xc': 5}, {'A': 95 if model == 'gaussian' else 140, 'w': 1.3}),
  ('lower-A-upper-w', {'A': {'lower': 110 if model == 'gaussian' else 160}, 'w': {'upper': 1.1}}, {'xc': 5}, {'A': 110 if model == 'gaussian' else 160, 'w': 1.1}),
  ('lower-xc', {'xc': {'lower': 5.1}}, {}, {'xc': 5.1}),
  ('upper-xc', {'xc': {'upper': 4.9}}, {}, {'xc': 4.9}),
 ]
 for case, bounds, fixed, expected_values in cases:
  bound_request = copy.deepcopy(source_request)
  bound_request.update(parameter_bounds=bounds, fixed_parameters=fixed,
                       initial_parameters={'A':target['area'],'xc':expected_values.get('xc',5),'w':1.2})
  label = f'bound-{model}-{case}'
  bounded = call(label, '/api/fit', bound_request)
  estimates = bounded['parameters']
  numeric_ok = bounded['converged'] and all(abs(estimates[k]['value']-v) <= 1e-6 for k,v in expected_values.items())
  free = [p for k,p in estimates.items() if k not in fixed]
  uncertainty_ok = all(p['standard_error'] is None and p['confidence_interval'] is None
                       and '贴边' in (p['uncertainty_reason'] or '') for p in free)
  fixed_ok = all(estimates[k]['standard_error'] is None and estimates[k]['confidence_interval'] is None
                 and '固定' in (estimates[k]['uncertainty_reason'] or '') for k in fixed)
  height = bounded['peak_geometry']['peak_height_uncertainty']
  height_ok = height['standard_error'] is None and height['confidence_interval'] is None and '贴边' in (height['reason'] or '')
  record(4, f'{model} {case} 边界及不确定度',
         {'boundary_values':expected_values,'boundary_tolerance':1e-6,'covariance':None,
          'free_se_ci':'空白并明确贴边原因','fixed_se_ci':'空白并明确固定原因','height_se_ci':'空白并明确贴边原因'},
         {'converged':bounded['converged'],'parameters':estimates,'covariance':bounded['covariance_matrix'],
          'height_uncertainty':height,'analysis_metadata':bounded['analysis_metadata']},
         numeric_ok and uncertainty_ok and fixed_ok and height_ok and bounded['covariance_matrix'] is None,
         [f'numerics/{label}-request.json',f'numerics/{label}-response.json'])
 interior_request = copy.deepcopy(source_request)
 interior_request.update(parameter_bounds={'A':{'lower':1,'upper':300},'w':{'lower':.1,'upper':4},'xc':{'lower':4,'upper':6}})
 label=f'interior-{model}'
 interior=call(label,'/api/fit',interior_request)
 verify_truth(4,f'{model} 内部有界解参数回收',interior,target,[f'numerics/{label}-response.json'])
 normal_ok=all(parameter_uncertainty_available(p) for p in interior['parameters'].values())
 height=interior['peak_geometry']['peak_height_uncertainty']
 normal_ok=normal_ok and parameter_uncertainty_available({'value':interior['peak_geometry']['peak_height'],**height})
 record(4,f'{model} 内部有界解保留SE/CI','自由参数和峰高仍有有限正SE及包含估计值的95%CI',
        {'parameters':interior['parameters'],'height_uncertainty':height},normal_ok,[f'numerics/{label}-response.json'])
 fixed_request=copy.deepcopy(source_request);fixed_request['fixed_parameters']={'xc':5}
 label=f'fixed-center-{model}';fr=call(label,'/api/fit',fixed_request)
 p=fr['parameters'];fixed_ok=p['xc']['standard_error'] is None and p['xc']['confidence_interval'] is None and '固定' in (p['xc']['uncertainty_reason'] or '')
 free_ok=all(parameter_uncertainty_available(p[k]) for k in ['A','w'])
 record(4,f'{model} 仅固定峰位的参数误差','xc不输出SE/CI并说明固定；自由A/w仍有SE及95%CI',p,fr['converged'] and fixed_ok and free_ok,[f'numerics/{label}-response.json'])

# Lorentz 以 H、xc、w 为独立参数写解析 Jacobian，避免调用项目的协方差函数。
H=lr['peak_geometry']['peak_height'];xc=lr['parameters']['xc']['value'];w=lr['parameters']['w']['value'];d=x-xc;q=1+4*d*d/w**2
J=np.column_stack([1/q,H*8*d/(w*w*q*q),H*8*d*d/(w**3*q*q)])
res=np.asarray(lr['residual']);cov=np.linalg.inv(J.T@J)*np.dot(res,res)/(len(x)-3)
se=np.sqrt(np.diag(cov));area_grad=np.array([np.pi*w/2,0,np.pi*H/2]);area_se=float(np.sqrt(area_grad@cov@area_grad))
expectedse={'H':float(se[0]),'xc':float(se[1]),'w':float(se[2]),'A':area_se}
reported={k:lr['parameters'][k]['standard_error'] for k in ['xc','w','A']};reported['H']=lr['peak_geometry']['peak_height_uncertainty']['standard_error']
relative={k:abs(reported[k]/expectedse[k]-1) for k in expectedse}
record(4,'Lorentz 标准误独立解析复核',{'relative_error_at_most':1e-5,'analytic_standard_errors':expectedse},
       {'reported':reported,'relative_error':relative},max(relative.values())<1e-5,['numerics/supplement-lorentz-response.json','numerics/test-plan.json'])

# 独立按峰高参数形式求方差，不调用项目的拟合或协方差实现。
H,xc,w=standard['peak_geometry']['peak_height'],standard['parameters']['xc']['value'],standard['parameters']['w']['value'];d=x-xc;e=np.exp(-4*np.log(2)*d*d/w**2);curve=H*e
J=np.column_stack([e,curve*8*np.log(2)*d/w**2,curve*8*np.log(2)*d*d/w**3]);res=np.asarray(standard['residual']);cov=np.linalg.inv(J.T@J)*np.dot(res,res)/(len(x)-3)
se=np.sqrt(np.diag(cov));jacA=np.array([w*np.sqrt(np.pi/(4*np.log(2))),0,H*np.sqrt(np.pi/(4*np.log(2)))]);areaSE=np.sqrt(jacA@cov@jacA)
actualse={k:standard['parameters'][k]['standard_error'] for k in ['xc','w','A']};actualse['H']=standard['peak_geometry']['peak_height_uncertainty']['standard_error'];expectedse={'H':se[0],'xc':se[1],'w':se[2],'A':areaSE};reldiff={k:abs(actualse[k]/expectedse[k]-1) for k in expectedse}
record(4,'参数及峰高标准误独立复核',{'relative_error_at_most':1e-5,'analytic_standard_errors':expectedse},{'reported':actualse,'relative_error':reldiff},max(reldiff.values())<1e-5,['numerics/package-gaussian-response.json','numerics/test-plan.json'])
factor=float(t.ppf(.975,len(x)-3));pvals={'H':H,'xc':xc,'w':w,'A':standard['parameters']['A']['value']};cis={k:standard['parameters'][k]['confidence_interval'] for k in ['xc','w','A']};cis['H']=standard['peak_geometry']['peak_height_uncertainty']['confidence_interval'];cdiff={k:float(np.max(np.abs(np.array(cis[k])-[pvals[k]-factor*expectedse[k],pvals[k]+factor*expectedse[k]]))) for k in cis}
record(4,'95% 置信区间独立复核',{'max_absolute_bound_difference':1e-6},{'reported':cis,'max_bound_difference':cdiff,'student_t_multiplier':factor},max(cdiff.values())<1e-6,['numerics/package-gaussian-response.json'])
for label,result in [('package',standard),('outlier',None)]:
 if result is None:
  oy=y.copy();oy[np.where(x==3.5)[0][0]]+=20
  np.savetxt(DIR/'one-outlier.csv',np.column_stack([x,oy]),delimiter=',',header='Angle [deg],Intensity [counts/s]',comments='')
  result=call('one-outlier','/api/fit',fit_request(x,oy))
 r=np.asarray(result['residual']);raw=np.asarray(result['raw_y']);base=np.asarray(result['baseline']);peak=np.asarray(result['peak_y']);total=np.asarray(result['total_y']);net=np.asarray(result['net_y'])
 errors={'total_equals_baseline_plus_peak':float(np.max(np.abs(total-base-peak))),'residual_equals_raw_minus_total':float(np.max(np.abs(r-(raw-total)))),'net_equals_raw_minus_baseline':float(np.max(np.abs(net-(raw-base))))}
 rmse=float(np.sqrt(np.mean(r*r)));sse=float(np.dot(r,r));count=int(np.sum(np.abs((r-np.mean(r))/np.std(r,ddof=1))>3))
 expcount=0 if label=='package' else 1
 record(5,label+' 曲线、残差、异常点核验',{'curve_identity_error_at_most':1e-10,'outlier_count':expcount},{'curve_identity_errors':errors,'rmse_recomputed':rmse,'rmse_reported':result['statistics']['rmse'],'sse_recomputed':sse,'sse_reported':result['statistics']['sse'],'outlier_recomputed':count,'outlier_reported':result['statistics']['outlier_count']},max(errors.values())<1e-10 and abs(rmse-result['statistics']['rmse'])<1e-10 and abs(sse-result['statistics']['sse'])<1e-8 and count==expcount==result['statistics']['outlier_count'],['numerics/package-gaussian-response.json' if label=='package' else 'numerics/one-outlier-response.json'])
summary={'timestamp':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),'service':'http://127.0.0.1:5176','method':'fresh HTTP requests','scope':'步骤3/4/5数值核验，补充构造谱已单独保存并注明公式。','total':len(checks),'passed':sum(c['passed'] for c in checks),'failed':[c['name'] for c in checks if not c['passed']],'checks':checks}
(OUT/'step3-5-numerics.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf8');print('TOTAL',summary['passed'],'/',summary['total'])

if summary['failed']:
 raise SystemExit(1)
