from pathlib import Path
import csv, io, json, hashlib, urllib.request, urllib.error, uuid, datetime
from openpyxl import Workbook
ROOT=Path.cwd(); OUT=ROOT/'output/acceptance-20261103-fixed'; PACKAGE=OUT/'sample-package'; SUP=OUT/'step2-supplementary-inputs'; SUP.mkdir(exist_ok=True)
BASE='http://127.0.0.1:5176'
checks=[]
def call(path, data=None, headers=None):
 req=urllib.request.Request(BASE+path,data=data,headers=headers or {})
 try:
  with urllib.request.urlopen(req,timeout=15) as response:return response.status,json.loads(response.read().decode())
 except urllib.error.HTTPError as e:return e.code,json.loads(e.read().decode())
def upload(path):
 data=path.read_bytes(); boundary='test'+uuid.uuid4().hex
 body=(f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="{path.name}"\r\nContent-Type: application/octet-stream\r\n\r\n').encode()+data+f'\r\n--{boundary}--\r\n'.encode()
 return call('/api/datasets',body,{'Content-Type':f'multipart/form-data; boundary={boundary}'})
def preview(info,sheet,x,y):return call('/api/preview',json.dumps({'dataset_id':info['dataset_id'],'sheet':sheet,'x_column':x,'y_column':y}).encode(),{'Content-Type':'application/json'})
def record(id,label,path,expected,actual,ok,origin='sample-package'):
 checks.append({'id':id,'label':label,'input':str(path.relative_to(OUT)).replace('\\','/'),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'origin':origin,'expected':expected,'actual':actual,'passed':bool(ok)})
for path in sorted((PACKAGE/'nine-formats').iterdir()):
 code,info=upload(path)
 if code!=200: record('import-'+path.suffix[1:],'有表头 '+path.suffix.upper()+' 导入与 X/Y 选列',path,{'upload':200,'preview':200,'x':[1,2,3,4,5],'y':[3,4,8,4,3]}, {'upload':code,'response':info},False);continue
 sheet=info['sheets'][0]; pcode,data=preview(info,sheet['name'],'x','y')
 ok=pcode==200 and data['x']==[1,2,3,4,5] and data['y']==[3,4,8,4,3] and data['audit']['excluded_pairs']==0
 record('import-'+path.suffix[1:],'有表头 '+path.suffix.upper()+' 导入与 X/Y 选列',path,{'upload':200,'preview':200,'x':[1,2,3,4,5],'y':[3,4,8,4,3],'excluded_pairs':0},{'upload':code,'preview':pcode,'sheets':info['sheets'],'selection':{'sheet':sheet['name'],'x':'x','y':'y'},'data':data},ok)
for filename,phrase in [('empty.csv','空'),('malformed.csv','列数')]:
 path=PACKAGE/'invalid'/filename; code,data=upload(path)
 record('invalid-'+filename,'异常文件 '+filename,path,{'http_status':422,'error_contains':phrase},{'http_status':code,'response':data},code==422 and phrase in data.get('detail',''))
path=SUP/'mixed-values.csv'; path.write_text('x,y,comment\n1,3,good\n2,4,good\n3,8,good\n4,4,good\n5,3,good\n6,bad,non-numeric\n,9,missing-x\n7,inf,nonfinite-y\n',encoding='utf8')
code,info=upload(path); pcode,data=preview(info,info['sheets'][0]['name'],'x','y')
expected={'x':[1,2,3,4,5],'y':[3,4,8,4,3],'excluded_pairs':3,'exclusion_reasons':{'y_non_numeric':1,'x_missing':1,'y_non_finite':1}}
ok=code==pcode==200 and data['x']==expected['x'] and data['y']==expected['y'] and data['audit']['excluded_pairs']==3 and data['audit']['exclusion_reasons']==expected['exclusion_reasons']
record('mixed-values','非数值、缺失和无穷值逐行提示',path,expected,{'upload':code,'preview':pcode,'sheets':info['sheets'],'data':data},ok,'supplementary synthesis; valid package values plus three labelled invalid rows')
code2,data2=preview(info,info['sheets'][0]['name'],'x','x')
record('same-xy','X/Y 同列提示',path,{'http_status':422,'error_contains':'不能相同'},{'http_status':code2,'response':data2},code2==422 and '不能相同' in data2.get('detail',''),'supplementary synthesis')
code2,data2=preview(info,info['sheets'][0]['name'],'x','not-a-column')
record('missing-column','不存在的数据列提示',path,{'http_status':422,'error_contains':'找不到'},{'http_status':code2,'response':data2},code2==422 and '找不到' in data2.get('detail',''),'supplementary synthesis')
path=SUP/'headerless-spacing.xy'; path.write_text('3  13\n4    14\n5  15\n',encoding='utf8')
code,info=upload(path); sheet=info['sheets'][0]; pcode,data=preview(info,sheet['name'],*sheet['numeric_columns'])
record('headerless-xy','无表头且不等长空格的 XY 首点保留',path,{'x':[3,4,5],'y':[13,14,15],'points':3},{'upload':code,'preview':pcode,'sheets':info['sheets'],'data':data},code==pcode==200 and data['x']==[3,4,5] and data['y']==[13,14,15],'supplementary synthesis; regression input from prior failed case')
path=SUP/'headerless.xlsx'; w=Workbook();s=w.active;s.title='Raw';[s.append(row) for row in [[3,13],[4,14],[5,15]]];w.save(path)
code,info=upload(path); sheet=info['sheets'][0];pcode,data=preview(info,sheet['name'],*sheet['numeric_columns'])
record('headerless-xlsx','无表头 Excel 首点保留',path,{'x':[3,4,5],'y':[13,14,15],'points':3},{'upload':code,'preview':pcode,'sheets':info['sheets'],'data':data},code==pcode==200 and data['x']==[3,4,5] and data['y']==[13,14,15],'supplementary synthesis; numeric cells matching headerless XY')
path=SUP/'multisheet.xlsx'; w=Workbook();s=w.active;s.title='Notes';s.append(['Purpose','Testing notes']);s.append(['User selection','Choose second or third sheet']);s=w.create_sheet('Spectrum A');[s.append(row) for row in [['x','aux','y'],[1,101,3],[2,102,4],[3,103,8],[4,104,4],[5,105,3]]];s=w.create_sheet('Spectrum B');[s.append(row) for row in [['x','aux','y'],[1,101,13],[2,102,14],[3,103,18],[4,104,14],[5,105,13]]];w.save(path)
code,info=upload(path)
for sheet,want in [('Spectrum A',[3,4,8,4,3]),('Spectrum B',[13,14,18,14,13])]:
 pcode,data=preview(info,sheet,'x','y')
 record('multisheet-'+sheet[-1],'Excel 工作表选择 '+sheet,path,{'sheets':['Notes','Spectrum A','Spectrum B'],'x':[1,2,3,4,5],'y':want},{'upload':code,'preview':pcode,'sheets':info['sheets'],'selected_sheet':sheet,'data':data},code==pcode==200 and [s['name'] for s in info['sheets']]==['Notes','Spectrum A','Spectrum B'] and data['x']==[1,2,3,4,5] and data['y']==want,'supplementary synthesis; package numeric values in worksheet A and values +10 in B')
report={'step':2,'name':'谱数据导入与校验','executed_at':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),'service':BASE,'transport':'Actual HTTP multipart upload and JSON preview','summary':{'cases':len(checks),'passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks)},'cases':checks}
(OUT/'step2-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf8')
print(json.dumps(report['summary']));print([(x['id'],x['passed']) for x in checks]);assert all(x['passed'] for x in checks)
