from pathlib import Path
import csv
import hashlib
import io
import json
import math
import sys
import urllib.request
import uuid
from datetime import datetime, timezone, timedelta
import numpy as np

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
BASE = 'http://127.0.0.1:5176'
DATA = ROOT / 'examples/public/zenodo_18845748'
ARCHIVE = ROOT / 'data/analysis/opensource_comparison_20260920'


def save(name, value):
    (OUT/name).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf8')


def load(path):
    return json.loads(path.read_text(encoding='utf8'))


def post(path, payload):
    request = urllib.request.Request(BASE+path, data=json.dumps(payload, allow_nan=False).encode(),
                                     headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(request, timeout=90) as response:
        return response.status, response.read()


def upload(path):
    boundary = uuid.uuid4().hex
    body = (f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="{path.name}"\r\n'
            f'Content-Type: application/octet-stream\r\n\r\n').encode()+path.read_bytes()+f'\r\n--{boundary}--\r\n'.encode()
    request = urllib.request.Request(BASE+'/api/datasets', data=body,
                                     headers={'Content-Type':'multipart/form-data; boundary='+boundary})
    with urllib.request.urlopen(request, timeout=90) as response:
        assert response.status == 200
        return json.load(response)


def preview(dataset, sheet, xcol, ycol):
    status, raw = post('/api/preview', {'dataset_id':dataset['dataset_id'], 'sheet':sheet,
                                      'x_column':xcol,'y_column':ycol})
    assert status == 200
    return json.loads(raw)


def fit(payload, name, endpoint='/api/fit'):
    save(name+'-request.json',payload)
    status, raw = post(endpoint,payload)
    result = json.loads(raw)
    save(name+'-result.json',result)
    assert status == 200 and result['converged'], name
    return result


def pv_height(parameters):
    return parameters['A']/parameters['w']*((1-parameters['mu'])*math.sqrt(4*math.log(2)/math.pi)+parameters['mu']*2/math.pi)


def main():
    started = datetime.now(timezone(timedelta(hours=8))).isoformat()
    manifest = load(DATA/'source.json')
    hashes = {}
    for record in manifest['files']:
        digest = hashlib.sha256((DATA/record['file']).read_bytes()).hexdigest()
        assert digest == record['sha256']
        hashes[record['file']] = digest
    verification = load(ARCHIVE/'verification.json')
    for name in ['benchmark_inputs.json','fityk_results.json','project_provenance.json']:
        digest = hashlib.sha256((ARCHIVE/name).read_bytes()).hexdigest()
        assert digest == verification['evidence_sha256'][name],name
        hashes[name] = digest
    provenance = load(ARCHIVE/'project_provenance.json')
    for name,digest in provenance['source_sha256'].items():
        assert digest == hashes[name]
    datasets = {name:upload(DATA/name) for name in ['Raman.xlsx','XRD.xlsx','XPS.xlsx']}
    reference = {r['id']:r for r in load(ARCHIVE/'fityk_results.json')}
    comparisons = []
    for case in load(ARCHIVE/'benchmark_inputs.json'):
        if case['kind'] != 'raman':
            continue
        identity = case['identity']
        spectrum = preview(datasets['Raman.xlsx'],identity['sheet'],'Wavenumber',identity['sample'])
        x,y = np.asarray(spectrum['x']),np.asarray(spectrum['y'])
        mask = (x>=identity['range'][0]) & (x<=identity['range'][1])
        # 原始工作表经当前选列接口处理后须与归档对照谱逐值相同。
        assert np.array_equal(x[mask],case['x'])
        assert np.array_equal(y[mask],case['y'])
        x,y = x[mask],y[mask]
        request = {'x':x.tolist(),'y':y.tolist(),'model':'psd_voigt1','baseline_kind':'line',
                   'anchors':[{'x':float(x[0]),'y':case['background'][0]}, {'x':float(x[-1]),'y':case['background'][-1]}],
                   'range_start':float(x[0]),'range_end':float(x[-1]),'initial_parameters':case['initial'],
                   'anchor_source':'manual','baseline_confirmed':True,'staged_fit':False,
                   'tolerance':1e-10,'max_function_evaluations':10000}
        result = fit(request,case['id'])
        assert np.allclose(result['baseline'],case['background'],rtol=1e-12,atol=1e-9)
        values = {k:v['value'] for k,v in result['parameters'].items()}
        ref = reference[case['id']]
        ref_values = ref['parameters']
        peak_difference = np.asarray(result['peak_y'])-np.asarray(ref['peak_y'])
        c = {'id':case['id'],'sheet':identity['sheet'],'y_column':identity['sample'],
             'points':len(x),'converged':result['converged'],'same_input':True,'same_background':True,
             'shared_initial_values':case['initial'],'project':values,'reference':ref_values,
             'delta_center':values['xc']-ref_values['xc'],'delta_fwhm':values['w']-ref_values['w'],
             'delta_height':pv_height(values)-pv_height(ref_values),
             'relative_height_pct':(pv_height(values)/pv_height(ref_values)-1)*100,
             'relative_area_pct':(values['A']/ref_values['A']-1)*100,
             'curve_rmse':float(np.sqrt(np.mean(peak_difference**2))),
             'project_rmse':result['statistics']['rmse'],'project_r2':result['statistics']['r_squared']}
        comparisons.append(c)
    save('raman-fityk-comparison.json',comparisons)
    fields = ['id','sheet','y_column','points','converged','delta_center','delta_fwhm','delta_height','relative_height_pct','relative_area_pct','curve_rmse','project_rmse','project_r2']
    with (OUT/'raman-fityk-comparison.csv').open('w',encoding='utf-8-sig',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=fields,extrasaction='ignore');writer.writeheader();writer.writerows(comparisons)
    tutorials=[]
    for name,filename,sheet,xcol,ycol,interval,xunit,yunit in [
        ('raman_demo','Raman.xlsx','Bare Ge','Wavenumber','Pristine #1',(280,320),'cm⁻¹','CCD counts'),
        ('xrd_demo','XRD.xlsx','BareGe','2Theta','Pristine Ge',(65.8,66.6),'°','原始强度单位')]:
        spectrum=preview(datasets[filename],sheet,xcol,ycol)
        request={'x':spectrum['x'],'y':spectrum['y'],'model':'psd_voigt1','baseline_kind':'line',
                 'anchors':[],'range_start':interval[0],'range_end':interval[1],
                 'anchor_source':'endpoint_default','baseline_confirmed':True}
        _,raw=post('/api/auto-peak-analysis',request)
        request['initial_parameters']=json.loads(raw)['initial_parameters']
        result=fit(request,name)
        result['analysis_metadata'].update(x_unit=xunit,y_unit=yunit)
        for kind in ['curves','parameters']:
            status,raw=post('/api/export',{'kind':kind,'result':result});assert status==200
            (OUT/f'{name}-{kind}.csv').write_bytes(raw)
        tutorials.append({'case':name,'file':filename,'sheet':sheet,'x_column':xcol,'y_column':ycol,
                          'valid_full_spectrum_points':len(spectrum['x']),'fit_points':len(result['x']),
                          'converged':result['converged'],'statistics':result['statistics'],
                          'parameters':{k:v['value'] for k,v in result['parameters'].items()}})
    config=load(ROOT/'examples/public/xps-ge2p-configuration.json')['request']
    source=config['source']
    spectrum=preview(datasets['XPS.xlsx'],source['sheet'],source['x_column'],source['y_column'])
    assert spectrum['x']==config['x'] and spectrum['y']==config['y']
    config['background']['confirmed']=True
    result=fit(config,'xps_demo','/api/xps/fit')
    tutorials.append({'case':'xps_demo','file':'XPS.xlsx','converged':result['converged'],
                      'fit_points':len(result['x']),'statistics':result['statistics'],
                      'diagnostics':result['diagnostics'],
                      'scope':'教学约束与背景回放；保留结构化残差及贴边警告，不作为化学态定量验收。'})
    save('public-real-spectra.json',tutorials)
    summary={'step':5,'started':started,'completed':datetime.now(timezone(timedelta(hours=8))).isoformat(),
             'service':BASE,'run':'修复后重新上传并求解','scope':'验收包之外补充的公开实测 Raman、XRD、XPS 原谱和已存档 Fityk 结果',
             'expected':'新启动服务可读取真实谱并复算；参考比较保持原始点、背景、模型、初值、权重和区间一致，记录峰参数偏差。',
             'actual':{'raman_fityk_cases':len(comparisons),'converged_cases':sum(c['converged'] for c in comparisons),
                       'max_abs_center_difference_cm-1':max(abs(c['delta_center']) for c in comparisons),
                       'max_abs_fwhm_difference_cm-1':max(abs(c['delta_fwhm']) for c in comparisons),
                       'max_abs_height_relative_pct':max(abs(c['relative_height_pct']) for c in comparisons),
                       'max_abs_area_relative_pct':max(abs(c['relative_area_pct']) for c in comparisons),
                       'max_curve_rmse':max(c['curve_rmse'] for c in comparisons),'tutorials':tutorials},
             'process_check_pass':True,'formal_accuracy_acceptance':'待测试方确认第三方对照允许误差',
             'reference_software':'Fityk 1.3.1 archived native MPFIT results',
             'threshold_source':'样例包 reference.json 仅规定合成 Gaussian 的工程回归阈值，不含本次真实谱第三方软件偏差阈值。',
             'reference_execution':'本次项目经HTTP重新求解；Fityk使用2026-09-20存档结果，本次未重新运行Fityk。',
             'sha256':hashes,'evidence':'real-reference/raman-fityk-comparison.csv and per-case request/result JSON'}
    (OUT.parent/'step5-reference.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf8')
    print(json.dumps({k:v for k,v in summary['actual'].items() if k!='tutorials'},ensure_ascii=False))


if __name__=='__main__':main()
