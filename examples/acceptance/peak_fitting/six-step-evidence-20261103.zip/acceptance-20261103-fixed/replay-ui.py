from pathlib import Path
import requests, base64
import csv, io, hashlib, zipfile, platform, os, json, struct, subprocess, socket, sys, time, urllib.request, tempfile, math
from playwright.sync_api import sync_playwright
from PIL import Image
ROOT=Path.cwd()
OUT=ROOT/'output/acceptance-20261103-fixed'
PACKAGE=OUT/'sample-package'
UI={}
def screenshot(pg,name):
 path=OUT/'ui'/name;path.parent.mkdir(exist_ok=True);pg.screenshot(path=str(path),full_page=True)
def batch_check(pg, files):
 ref=json.loads((PACKAGE/'reference.json').read_text(encoding='utf8'))
 def metric(g, center):
  for key,actual,expected in [('center',g['peak_position'],center),('fwhm',g['fwhm'],ref['fwhm']),('height',g['peak_height'],ref['height']),('area',g['area_total'],ref['area'])]: assert abs(actual-expected)<ref['abs_tolerance'][key], (key,actual,expected)
  h=g['peak_height_uncertainty']; assert h['standard_error']>0 and h['confidence_interval'][0]<g['peak_height']<h['confidence_interval'][1]

 t=lambda id:pg.locator('[data-test="'+id+'"]:visible').first
 btn=lambda name:pg.get_by_role('button',name=name,exact=True)
 pg.on('dialog',lambda d:d.accept())
 pg.get_by_role('combobox',name='分析类型').select_option(label='XRD 峰拟合')
 pg.locator('input[accept*=xye]').first.set_input_files(str(PACKAGE/'source/standard.csv'))
 screenshot(pg,'01-import.png'); btn('应用到图表').click()
 pg.get_by_role('tab',name='峰参数').click(); btn('添加峰').click()
 pg.get_by_role('tab',name='基线设置').click(); btn('预览基线').click(); pg.get_by_text('已复核当前基线',exact=True).click(); screenshot(pg,'02-baseline.png')
 pg.get_by_role('tab',name='峰参数').click()
 with pg.expect_response(lambda r:r.url.endswith('/api/auto-peak-analysis')) as initial:btn('自动估计并采用初值').click()
 UI['initial_estimate']=initial.value.json(); screenshot(pg,'03-initial.png')
 with pg.expect_response(lambda r:r.url.endswith('/api/fit')) as resp:btn('开始拟合').click()
 fit=resp.value.json(); assert fit['converged'] and len(fit['x'])==201
 UI['single_statistics']=fit['statistics'];UI['single_parameters']=fit['parameters'];UI['single_geometry']=fit['peak_geometry'];files['single/response.json']=json.dumps(fit,ensure_ascii=False,indent=2).encode()
 UI['displayed_center']=pg.get_by_role('region',name='各峰结果概览',exact=True).locator('tbody tr').first.locator('td').nth(1).inner_text()
 assert abs(float(UI['displayed_center'])-fit['parameters']['xc']['value'])<1e-5
 plots=pg.locator('[data-test=multi-plot]:visible').evaluate('(e)=>({traces:e.data.map(t=>({name:t.name,x:Array.from(t.x||[]),y:Array.from(t.y||[])})),xTitle:e._fullLayout.xaxis.title.text,yTitle:e._fullLayout.yaxis.title.text})')
 UI['graph']=plots
 assert '°' in plots['xTitle'] and 'counts/s' in plots['yTitle']
 for key in ('raw_y','baseline','total_y','peak_y'):assert any(t['y']==fit[key] for t in plots['traces']),key
 residual_trace=pg.locator('[data-test=multi-residual]:visible').evaluate('(e)=>Array.from(e.data[0].y)');assert residual_trace==fit['residual']
 UI['residual_ui_points']=len(residual_trace)
 screenshot(pg,'04-single-fit.png')
 pg.get_by_role('tab',name='完整参数',exact=True).click();t('peak-select-p1').click()
 dialog=pg.get_by_role('dialog',name='p1 · 峰 1 详细求解结果',exact=True)
 UI['parameter_dialog_text']=dialog.inner_text()
 assert '95% CI' in UI['parameter_dialog_text'] and '净峰高标准误' in UI['parameter_dialog_text']
 screenshot(pg,'04b-parameter-uncertainty.png');pg.get_by_role('button',name='关闭峰结果详情',exact=True).click()

 def download(button):
  with pg.expect_download() as event:button.click()
  d=event.value; assert d.failure() is None
  return d.path().read_bytes()
 def png(data):
  with Image.open(io.BytesIO(data)) as im: im.load(); assert im.format=='PNG' and min(im.size)>100; print('PNG',im.size)
 pg.get_by_role('tab',name='比较与归档').click()
 pg.get_by_text('模型比较',exact=True).click()
 with pg.expect_response(lambda r:r.url.endswith('/api/model-comparison')) as compared:t('compare-models').click()
 UI['model_comparison']=compared.value.json();screenshot(pg,'05-model-comparison.png')
 single={}
 for key,name in [('curves','曲线 CSV'),('parameters','参数 CSV'),('image','拟合图 PNG'),('cfg','配置 JSON')]:
  t('result-export-menu').locator('summary').click(); single[key]=download(btn(name))
 png(single['image'])
 metric(fit['peak_geometry'],5.)
 files.update({'single/curves.csv':single['curves'],'single/parameters.csv':single['parameters'],'single/fit.png':single['image'],'single/configuration.json':single['cfg']})
 records=list(csv.DictReader(io.StringIO(single['curves'].decode('utf-8-sig'))))
 assert len(records)==201
 if not os.getenv('DRY_RUN'):
  assert all((r['x_unit'],r['y_unit'])==('°','counts/s') for r in records)
  for i,r in enumerate(records):
   for key in ('x','raw_y','baseline','net_y','peak_y','total_y','residual'):assert float(r[key])==fit[key][i]
  single_rows=list(csv.reader(io.StringIO(single['parameters'].decode('utf-8-sig'))))
  h=single_rows[0]
  for key in ('xc','w','A'):
   row=dict(zip(h,next(r for r in single_rows if r and r[0]==key)))
   assert float(row['value'])==fit['parameters'][key]['value'] and float(row['ci95_lower'])==fit['parameters'][key]['confidence_interval'][0]
   assert row['unit']==('counts/s × °' if key=='A' else '°')
 print('single',fit['parameters']['xc']['value'],fit['parameters']['w']['value'])
 pg.get_by_text('拟合配置',exact=True).click(); t('multi-template').click()
 pg.locator('[data-test=batch-import-footer]:visible').locator('../..').locator('input[multiple][accept*=xye]').set_input_files([str(PACKAGE/'source'/f'spec{k}.csv') for k in range(2)])
 t('batch-select-all').click(); t('batch-commit-selection').click()
 t('batch-units').check(); t('batch-prepare').click()
 t('batch-bulk-toggle').click(); t('batch-confirm-all').click(); screenshot(pg,'06-batch-baselines.png');t('batch-start').click()
 pg.get_by_text('批次计算已结束',exact=True).wait_for(state='visible')
 for ix in range(2):
  t('batch-view-'+str(ix+1)).click()
  image_data=download(btn('谱图 PNG')); png(image_data); files[f'batch/spec{ix}.png']=image_data
  print('batch UI',t('batch-detail-title').inner_text());screenshot(pg,f'07-batch-{ix+1}.png')
 pg.get_by_role('tab',name='导出结果',exact=False).last.click()
 data={}
 UI['batch']={}
 for scope in ('all','current'):
  pg.get_by_label('拟合结果导出范围',exact=True).select_option(scope)
  for kind in ('configuration','curves','parameters'):
   pg.get_by_label('拟合结果导出内容',exact=True).select_option(kind)
   data[scope,kind]=download(t('export-fit')); files[f'batch/{scope}-{kind}.'+('json' if kind=='configuration' else 'csv')]=data[scope,kind]
 for scope,n in [('all',2),('current',1)]:
  snap=json.loads(data[scope,'configuration'].decode('utf-8-sig'))
  curve=list(csv.DictReader(io.StringIO(data[scope,'curves'].decode('utf-8-sig'))))
  params=list(csv.DictReader(io.StringIO(data[scope,'parameters'].decode('utf-8-sig'))))
  assert len(snap['rows'])==n and len(curve)==201*n
  for row in snap['rows']:
   result=row['result']; assert result and result['converged']
   metric(result['components'][0]['peak_geometry'],ref['centers'][int(row['request']['source']['filename'][4])])
   cs=[r for r in curve if r['task_id']==row['id']]
   assert len(cs)==201
   for i,r in enumerate(cs):
    for name,field in [('x','x'),('raw_y','raw_y'),('baseline','baseline'),('total_y','total_y'),('residual','residuals')]:
     assert float(r[name])==result[field][i]
    assert abs(float(r['peak:p1'])-result['components'][0]['y'][i])<1e-9
    if not os.getenv('DRY_RUN'):assert (r['x_unit'],r['y_unit'])==('°','counts/s')
   ps={r['parameter']:r for r in params if r['task_id']==row['id'] and r['component_id']=='p1'}
   for key in ('xc','w','A'):
    p=result['components'][0]['parameters'][key]
    assert float(ps[key]['value'])==p['value'] and float(ps[key]['standard_error'])==p['standard_error']
    if not os.getenv('DRY_RUN'):
     assert ps[key]['unit']==('counts/s × °' if key=='A' else '°')
     assert [float(ps[key]['ci95_lower']),float(ps[key]['ci95_upper'])]==p['confidence_interval']
  UI['batch'][scope]={'spectra':n,'curve_rows':len(curve),'parameter_rows':len(params),'status':[row['status'] for row in snap['rows']],'parameters':[row['result']['components'][0]['parameters'] for row in snap['rows']]}
  print(scope,n,'spectra;',len(curve),'curve rows;',len(params),'parameter rows')

def check_ui_import(pg):
 results=[]
 pg.on('dialog',lambda d:d.accept())
 for name in sorted((PACKAGE/'nine-formats').iterdir()):
  pg.locator('input[accept*=xye]').first.set_input_files(str(name))
  pg.get_by_role('combobox',name='X 列',exact=True).select_option('x')
  pg.get_by_role('combobox',name='Y 列',exact=True).select_option('y')
  with pg.expect_response(lambda r:r.url.endswith('/api/preview')) as response:pg.get_by_role('button',name='应用到图表',exact=True).click()
  value=response.value.json();assert value['x']==[1,2,3,4,5] and value['y']==[3,4,8,4,3]
  results.append({'file':name.name,'points':len(value['x']),'passed':True})
 for name in sorted((PACKAGE/'invalid').iterdir()):
  with pg.expect_response(lambda r:r.url.endswith('/api/datasets')) as response:pg.locator('input[accept*=xye]').first.set_input_files(str(name))
  res=response.value; assert res.status==422
  detail=res.json()['detail'];pg.get_by_text(detail,exact=False).first.wait_for()
  results.append({'file':name.name,'actual':detail,'passed':True});screenshot(pg,'invalid-'+name.stem+'.png')
 UI['import_ui']=results

def main():
 files={}
 with sync_playwright() as pw:
  b=pw.chromium.launch(channel='msedge',headless=True);UI['browser']='Microsoft Edge '+b.version
  pg=b.new_page(viewport={'width':1680,'height':1040},accept_downloads=True);pg.set_default_timeout(15000)
  errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
  try:
   pg.goto('http://127.0.0.1:5175/');check_ui_import(pg)
   pg.close();pg=b.new_page(viewport={'width':1680,'height':1040},accept_downloads=True);pg.set_default_timeout(15000);pg.on('pageerror',lambda e:errors.append(str(e)));pg.goto('http://127.0.0.1:5175/')
   batch_check(pg,files);UI['page_errors']=errors;assert not errors;UI['passed']=True
  except Exception as e:
   UI['passed']=False;UI['failure']=str(e);screenshot(pg,'failure.png');print(pg.locator('body').inner_text()[-3500:]);raise
  finally:
   (OUT/'step6-ui-results.json').write_text(json.dumps(UI,ensure_ascii=False,indent=2),encoding='utf8')
   for name,value in files.items():
    target=OUT/'downloads'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(value)
   b.close()
if __name__=='__main__':main()
