from pathlib import Path
import datetime
import html
import json

OUT = Path(__file__).resolve().parent
read = lambda name: json.loads((OUT / name).read_text(encoding='utf8'))
env, imports, nums, ui, bound, real, ref = [read(name) for name in (
    'environment.json', 'step2-results.json', 'step3-5-numerics.json',
    'step6-ui-results.json', 'step4-bound-ui-results.json', 'step5-reference.json',
    'sample-package/reference.json')]
assert imports['summary']['failed'] == 0
assert nums['total'] == nums['passed'] == 41
assert ui['passed'] and bound['passed'] and not ui['page_errors'] and not bound['page_errors']
assert real['process_check_pass'] and real['actual']['converged_cases'] == 33
assert 'Ran 146 tests' in (OUT/'backend-regression.txt').read_text(encoding='utf8')
assert '17 passed' in (OUT/'frontend-regression.txt').read_text(encoding='utf8')

rows = [
    dict(step=1, name='准备工作', expected='页面和计算服务正常，样例、参考值、测试环境及允许误差明确。',
         actual='修复后重新启动页面与计算服务，5175/5176 均返回 HTTP 200。原验收包 30 个文件的 SHA256 全部吻合，继续使用包内原定容差。记录环境版本及本轮源文件哈希。',
         verdict='通过', evidence=['environment.json', 'package-check.json', 'source-sha256.json']),
    dict(step=2, name='谱数据导入与校验', expected='CSV、TXT、TSV、DAT、XY、XYE、XLS、XLSX、XLSM 识别正确；工作表和 X/Y 可选；异常明确提示，无丢点、错列。',
         actual='九种格式各 5 对数据逐点一致；浏览器重新上传及选列正常。空文件、列数不符、混合坏值、同列、缺列、无表头首点及多工作表均重新核验，接口 18/18 通过；九格式及两异常样本的浏览器检查通过。',
         verdict='通过', evidence=['step2-results.json', 'step6-ui-results.json', 'ui/invalid-malformed.png']),
    dict(step=3, name='基线处理与参数初始化', expected='无基线、常数、直线、多项式、Spline、B-Spline 正常；锚点、区间及可调整的初值生效。',
         actual='6 种基线逐点核对，最大绝对差 7.11×10⁻¹⁵；扣背景后参数均回收。原包自动初值为峰位 5°、FWHM 1.201481°、面积 102.349716 counts/s × °。初值可调整，2–8° 区间保留 121 点。步骤 3 数值检查 13/13 通过。',
         verdict='通过', evidence=['step3-5-numerics.json', 'ui/02-baseline.png', 'ui/03-initial.png']),
    dict(step=4, name='单峰拟合与模型比较', expected='Gaussian、Lorentz 收敛；初值、区间、固定及上下限有效；参数及不确定度正确。边界上普通线性估计不适用时须留空并解释，可同口径比较模型。',
         actual='步骤 4 数值检查 26/26 通过。原失败用例 A=95、w=1.3、固定 xc=5，约束继续生效；A/w 的标准误和 95% CI 均为空，提示“存在贴边参数，线性协方差不适用”。两模型八类边界、正常内部解、固定参数和独立解析误差核验全部通过；实际界面及参数 CSV 一致。Gaussian 谱两模型 RMSE 为 0.050252 / 3.979555。',
         verdict='通过', evidence=['step3-5-numerics.json', 'step4-bound-ui-results.json', 'ui/09-bound-ci-corrected.png', 'downloads/bound-parameters.csv']),
    dict(step=5, name='拟合结果评价', expected='原始谱、基线、净峰、总拟合、残差对应正确；误差、异常点数和关键参数满足参考容差。',
         actual='包内标准谱四项参数均在原定容差内。201 点曲线与实际响应逐点一致，曲线恒等式最大差 1.42×10⁻¹⁴；RMSE、SSE 独立重算一致，正常谱异常数 0、注入单异常点后为 1。33 条 Raman 与 3 份演示实谱重新求解，全部收敛；对第三方存档记录偏差。',
         verdict='通过（包内容差）', evidence=['step3-5-numerics.json', 'step5-reference.json', 'ui/04-single-fit.png', 'ui/04b-parameter-uncertainty.png']),
    dict(step=6, name='结果导出与核验', expected='单谱及批量曲线 CSV、参数 CSV、PNG 正常打开，曲线、参数、单位及不确定度说明与界面一致，无遗漏错位。',
         actual='实际下载单谱和两条谱的批量结果。单谱/整批/当前谱曲线为 201/402/201 行，整批/当前谱参数为 46/23 行；数值、°、counts/s、SE/CI 逐项一致。单谱 PNG 2800×1600，两张批量 PNG 2800×1800，均可解码。边界导出正确保留空 SE/CI 与原因。两轮浏览器流程页面错误均为 0。',
         verdict='通过', evidence=['step6-ui-results.json', 'downloads/single/curves.csv', 'downloads/batch/all-parameters.csv', 'downloads/batch/all-curves.csv', 'downloads/batch/spec1.png', 'downloads/bound-parameters.csv']),
]
limits = ['本轮判定限于本机、原验收样例包预设容差及明确标注的补充用例。',
          '实谱第三方对照未规定正式允许误差，本次记录差异，不作正式精度合格判定。',
          'Fityk 使用已核验哈希的 2026-09-20 存档，本次未重新运行 Fityk。',
          '原表指定的 D3-202 现场、仪器及 2027 年 10 月计划仍需现场执行。']
summary = dict(date='2026-11-03', scope=limits[0], conclusion='本机样例复测六步骤全部通过；上一轮步骤 4 的边界不确定度问题已修复。',
               rows=rows, formal_limits=limits, cases=dict(imports=dict(passed=18,total=18),numerics=dict(passed=41,total=41),backend_tests=146,frontend_tests=17),
               generated_at=datetime.datetime.now().astimezone().isoformat())
(OUT/'六步骤判定.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf8')
e = lambda value: html.escape(str(value))
links = lambda paths: ' · '.join(f'<a href="{e(path)}">{e(Path(path).name)}</a>' for path in paths)
parts = ['''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>峰拟合项目六步骤复测报告 · 边界不确定度修复后</title><style>
body{font:15px/1.65 "Microsoft YaHei",sans-serif;color:#263544;max-width:1280px;margin:32px auto;padding:0 24px;background:#fff}h1{font-size:28px;color:#16375b;margin-bottom:8px}h2{font-size:20px;margin-top:30px}p{margin:12px 0}.lead{padding:16px;border-left:5px solid #146843;background:#eff9f3;font-size:18px}.note{padding:14px;background:#f0f5fa;border-radius:5px}table{width:100%;border-collapse:collapse;margin:16px 0;font-size:14px}th,td{padding:12px;border:1px solid #d7e1eb;text-align:left;vertical-align:top}th{background:#edf3f8}.pass{color:#146843;font-weight:bold;white-space:nowrap}a{color:#1b5f9f;overflow-wrap:anywhere}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:13px/1.6 Consolas,"Microsoft YaHei",monospace;background:#f5f7f9;padding:12px}details{border:1px solid #d7e1eb;padding:9px 14px;margin:9px 0}summary{cursor:pointer;font-weight:bold}img{width:100%;height:auto;border:1px solid #d7e1eb}figure{margin:24px 0}figcaption,.evidence{font-size:12px;color:#536476}@media(max-width:800px){table{font-size:12px}th,td{padding:7px}}@media print{body{max-width:none;margin:0;font-size:11px}table{font-size:10px}a{color:inherit}figure{break-inside:avoid}}</style>''',
         '<h1>峰拟合项目六步骤复测报告</h1><p>2026 年 11 月 3 日 · 边界不确定度修复后 · 重启服务并重新执行</p>',
         '<p class="lead"><strong>本机样例复测 6 项全部通过。</strong>上一轮步骤 4 的贴边参数标准误、置信区间及缺少提示问题已修复，原失败请求经接口、浏览器及实际 CSV 下载重新验证。</p>',
         '<p>本轮重新上传原验收包，沿用原定容差；六种已知背景、Lorentz 谱、边界、异常点和多表文件使用保留公式与参考值的补充数据。报告及请求、响应、截图、下载文件均为修复后新生成。上一轮不通过报告保留供追溯。</p>',
         '<table><thead><tr><th>测试步骤</th><th>预期结果</th><th>实际结果</th><th>是否通过</th></tr></thead><tbody>']
for row in rows:
    parts.append(f'<tr><td>{row["step"]}. {e(row["name"])}</td><td>{e(row["expected"])}</td><td>{e(row["actual"])}<p class="evidence">{links(row["evidence"])}</p></td><td class="pass">{e(row["verdict"])}</td></tr>')
parts.append('</tbody></table><h2>步骤 4 修复前后对照</h2><p>复现设置为 standard.csv、Gaussian、直线基线、0–10°，固定 xc=5，A 初值 90、上限 95，w 初值 1.8、下限 1.3。采用整个自由参数协方差不可用的保守处理；固定参数仍注明“固定参数”。本次没有计算适用于边界的非线性置信区间。</p><table><tr><th>检查项</th><th>修复前</th><th>本次实际结果</th></tr>')
for label, before, after in [
    ('面积 A ≤ 95', '值 95；95% CI [92.823888920, 97.176111080]，未提示不适用', '值 95；标准误和 CI 留空，显示贴边原因'),
    ('峰宽 w ≥ 1.3', '值 1.3；95% CI [1.265614909, 1.334385091]，未提示不适用', '值 1.3；标准误和 CI 留空，显示贴边原因'),
    ('固定 xc=5', '标准误及 CI 留空，原因“固定参数”', '保留该正确行为'),
    ('正常内部参数', '可计算标准误与区间', '继续输出有限正标准误及包含估计值的区间'),
    ('界面 / CSV', '保留了不适用的区间数值', '空值与“存在贴边参数，线性协方差不适用”一致')]:
    parts.append(f'<tr><td>{e(label)}</td><td>{e(before)}</td><td>{e(after)}</td></tr>')
parts.append('</table><p>根因是单峰的不确定度诊断仅对非对称峰型执行。修复统一了各峰型的检查，使用拟合后的物理参数判断边界，避免把 LM 的对数/变换坐标误当参数；边界提示复用现有结果字段，界面和导出同步呈现。'+links(['fix.diff','test_single_peak_uncertainty.py','regression-before.txt','backend-regression.txt','step4-bound-ui-results.json'])+'</p>')
parts.append('<figure><img src="ui/09-bound-ci-corrected.png" alt="修复后的实际边界参数弹窗"><figcaption>重启后浏览器截图，A、w 的标准误及 CI 均为 —，并显示原因。</figcaption></figure>')
parts.append('<h2>标准谱参数及正常不确定度</h2><p>Gaussian，X 单位 °，Y 单位 counts/s，201 点，0–10°，固定直线背景，未加权最小二乘。允许绝对偏差来自原包 reference.json。</p><table><tr><th>指标</th><th>参考值</th><th>本轮浏览器值</th><th>绝对偏差</th><th>容差</th><th>判定</th></tr>')
for label, key, field, expected in [('峰位 / °','center','peak_position',5),('FWHM / °','fwhm','fwhm',ref['fwhm']),('净峰高 / counts/s','height','peak_height',ref['height']),('面积 / counts/s × °','area','area_total',ref['area'])]:
    actual=ui['single_geometry'][field]; tolerance=ref['abs_tolerance'][key]
    assert abs(actual-expected)<=tolerance
    parts.append(f'<tr><td>{label}</td><td>{expected:.10g}</td><td>{actual:.12g}</td><td>{abs(actual-expected):.7g}</td><td>{tolerance}</td><td class="pass">通过</td></tr>')
parts.append('</table><p>Gaussian 与 Lorentz 正常标准误分别用独立解析 Jacobian 核验，最大相对差 3.17×10⁻⁸、3.68×10⁻⁸，均小于原定 10⁻⁵。新增回归覆盖上下限、峰位边界、固定参数、内部解和不同 X 单位下的物理坐标。</p>')
parts.append('<h2>实谱及第三方存档对照</h2><p>33 条 Raman 经当前服务重新求解，原始点、固定背景、模型、初值、权重和区间与已核验的参考一致。Raman、XRD、XPS 演示谱分别以 52、31、521 点重新求解。XPS 的贴边和残差相关警告继续保留。</p><table><tr><th>对照项</th><th>最大差异</th></tr>')
labels={'max_abs_center_difference_cm-1':'峰位绝对差 / cm⁻¹','max_abs_fwhm_difference_cm-1':'FWHM 绝对差 / cm⁻¹','max_abs_height_relative_pct':'峰高相对差 / %','max_abs_area_relative_pct':'面积相对差 / %','max_curve_rmse':'曲线均方根偏差 / 原强度单位'}
for key,label in labels.items():
    parts.append(f'<tr><td>{label}</td><td>{real["actual"][key]:.12g}</td></tr>')
parts.append('</table><p>'+links(['step5-reference.json','real-reference/raman-fityk-comparison.csv'])+'</p><p class="note">'+'<br>'.join(e(s) for s in limits)+'</p>')
parts.append('<h2>环境与回归验证</h2><table>')
for label,value in [('环境记录时间',env['recorded_at']),('系统',env['os']),('Python / Node',env['python'].split()[0]+' / '+env['node']),('浏览器',env['browser']),('应用版本',env['app_version']),('计算依赖','；'.join(f'{k} {v}' for k,v in env['versions'].items())),('版本',env['git_revision']),('工作区',env['worktree']),('回归测试','后端 146/146、前端相关测试 17/17 通过；前端类型检查与构建通过。')]:
    parts.append(f'<tr><th>{e(label)}</th><td>{e(value)}</td></tr>')
parts.append('</table><p>'+links(['environment.json','source-sha256.json','backend-regression.txt','frontend-regression.txt','frontend-build.txt'])+'</p>')
parts.append('<h2>逐用例预期、实际与判定</h2><p>接口导入 18/18；数值 41/41（步骤 3：13、步骤 4：26、步骤 5：2）；浏览器九格式与两异常样本、单谱/批量导出及独立边界流程通过。</p>')
for case in imports['cases']:
    parts.append(f'<details><summary>步骤 2 · {e(case["label"])} · 通过</summary><p>预期</p><pre>{e(json.dumps(case["expected"],ensure_ascii=False,indent=2))}</pre><p>实际</p><pre>{e(json.dumps(case["actual"],ensure_ascii=False,indent=2))}</pre></details>')
for case in nums['checks']:
    assert case['passed']
    parts.append(f'<details><summary>步骤 {case["step"]} · {e(case["name"])} · 通过</summary><p>预期</p><pre>{e(json.dumps(case["expected"],ensure_ascii=False,indent=2))}</pre><p>实际</p><pre>{e(json.dumps(case["actual"],ensure_ascii=False,indent=2))}</pre><p>{links(case.get("evidence",[]))}</p></details>')
parts.append('<p>复测脚本与汇总：'+links(['step2-run.py','numerics-check.py','replay-ui.py','replay-bound-ui.py','real-reference/run_reference.py','六步骤判定.json'])+'</p></html>')
(OUT/'六步骤复测报告.html').write_text('\n'.join(parts),encoding='utf8')
print('Six-step report generated; 6 steps pass within recorded scope.')
